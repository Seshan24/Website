-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 20, 2024 at 03:03 AM
-- Server version: 8.3.0
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `horizon_jet`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `email`, `password`, `created_at`) VALUES
(5, 'tharuka@gmail.com', 'tharuka@gmail.com', 'tharuka@gmail.com', '2024-11-17 19:20:20'),
(2, 'admin2', 'admin2@gmail.com', 'zzzz', '2024-11-17 19:08:06'),
(10, 'admin1', 'admin1@gmail.com', 'admin', '2024-11-18 20:05:21'),
(4, 'vrtrtvrvr', 'vrtrtvrvr@gmail.com', 'vrtrtvrvr@gmail.co,', '2024-11-17 19:11:33'),
(6, 'shehan@gmail.com', 'shehan@gmail.com', 'shehan@gmail.com', '2024-11-17 19:22:08'),
(7, 'admin@gmail.com', 'admin@gmail.com', 'admin@gmail.com', '2024-11-17 19:56:55'),
(8, 'bellac@gmail.com', 'bellac@gmail.com', 'bellac@gmail.com', '2024-11-17 19:57:42'),
(9, 'denura@gmail.com', 'denura@gmail.com', 'denura@gmail.com', '2024-11-17 20:06:51'),
(11, 'chandrika', 'chandrika@gmail.com', '1111', '2024-11-19 15:17:59'),
(12, 'rfvfgvgtv', 'vgtg@gmail.com', 'vgtg@gmail.com', '2024-11-19 16:48:13');

-- --------------------------------------------------------

--
-- Table structure for table `flights`
--

DROP TABLE IF EXISTS `flights`;
CREATE TABLE IF NOT EXISTS `flights` (
  `id` int NOT NULL AUTO_INCREMENT,
  `flight_name` varchar(255) NOT NULL,
  `departure_city` varchar(255) NOT NULL,
  `arrival_city` varchar(255) NOT NULL,
  `departure_date` date NOT NULL,
  `return_date` date DEFAULT NULL,
  `passengers` int NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `class` enum('economy','business','first') NOT NULL DEFAULT 'economy',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `flights`
--

INSERT INTO `flights` (`id`, `flight_name`, `departure_city`, `arrival_city`, `departure_date`, `return_date`, `passengers`, `status`, `price`, `class`) VALUES
(21, 'Qatar Airlines', 'Katunayake Airport CMB', 'South Africa', '2024-11-01', '2024-11-06', 2, 'active', 1800.00, 'economy'),
(22, 'Iran Airlines', 'srilanka', 'usa', '2024-11-01', '2024-11-02', 11, 'active', 1299.00, 'business'),
(18, 'British Ailrines', ' United Kingdom', 'Bandaranaike International Airport (CMB)', '2024-10-10', '2024-11-01', 12, 'active', 1900.00, 'first'),
(19, 'Kuwait Airlines', 'Srilanka', 'Canada', '2024-11-05', '2024-11-22', 12, 'active', 1200.00, 'first');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `full_name` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL,
  `security_answer` varchar(80) NOT NULL,
  `role` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `password`, `security_answer`, `role`) VALUES
(44, 'tharusha', 'tharushadishan@gmail.com', '6a990525', 'kevi', ''),
(45, 'chandrika', 'chandrika@gmail.com', '1111', 'kevi', ''),
(34, 'shirley nishantha', 'shirley@gmail.com', 'tharusha', 'kevi', ''),
(43, 'evan', 'evan@gmail.com', 'zzzz', 'kevi', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
